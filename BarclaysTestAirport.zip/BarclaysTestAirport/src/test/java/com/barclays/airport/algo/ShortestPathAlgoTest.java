package com.barclays.airport.algo;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.barclays.airport.dto.Edge;
import com.barclays.airport.dto.FlightInfo;
import com.barclays.airport.dto.TwoDimentinalGraph;

public class ShortestPathAlgoTest {

	List<String> nodes = null;
	List<Edge> edges = null;
	ShortestPathAlgo shortestPathAlgo = null;
	
	@Test
	public void testExcute() {
		nodes = new ArrayList<String>();
		edges = new ArrayList<Edge>();

		for (int i = 0; i <= 11; i++) {
			if (i == 0) {
				nodes.add("Concourse_A_Ticketing");
			} else {
				if (i == 11) {
					nodes.add("BaggageClaim");
				} else {
					nodes.add("A" + i);
				}
			}
		}

		// Add Edges
		addLane("Edge_0", 0, 5, 5);
		addLane("Edge_1", 5, 11, 5);
		addLane("Edge_2", 5, 10, 4);
		addLane("Edge_3", 5, 1, 6);
		addLane("Edge_4", 1, 2, 1);
		addLane("Edge_5", 2, 3, 1);
		addLane("Edge_6", 3, 4, 1);
		addLane("Edge_7", 10, 9, 1);
		addLane("Edge_8", 9, 8, 1);
		addLane("Edge_9", 8, 7, 1);
		addLane("Edge_10", 7, 6, 1);

		// Lets check from location Loc_1 to Loc_10
		TwoDimentinalGraph graph = new TwoDimentinalGraph(nodes, edges);
		shortestPathAlgo = new ShortestPathAlgo(graph);
		Map<String, FlightInfo> departures = new HashMap<>();
		departures.put("UA10", new FlightInfo(nodes.get(1), "MIA", "08:00") );
		departures.put("UA11", new FlightInfo(nodes.get(1), "LAX", "09:00") );
		departures.put("UA12", new FlightInfo(nodes.get(1), "JFK", "09:45") );
		departures.put("UA13", new FlightInfo(nodes.get(2), "JFK", "09:30") );
		departures.put("UA14", new FlightInfo(nodes.get(2), "JFK", "09:45") );
		departures.put("UA15", new FlightInfo(nodes.get(2), "JFK", "10:00") );
		departures.put("UA16", new FlightInfo(nodes.get(3), "JFK", "09:00") );
		departures.put("UA17", new FlightInfo(nodes.get(4), "MHT", "09:15") );
		departures.put("UA18", new FlightInfo(nodes.get(5), "LAX", "10:15") );
		departures.put("ARRIVAL", new FlightInfo(nodes.get(11), null, null) );

		Map<String, String[]> bags = new LinkedHashMap<>();
		bags.put("0001", new String[] { nodes.get(0), departures.get("UA12").getFlightNumber() });
		bags.put("0002", new String[] { nodes.get(5), departures.get("UA17").getFlightNumber() });
		bags.put("0003", new String[] { nodes.get(2), departures.get("UA10").getFlightNumber() });
		bags.put("0004", new String[] { nodes.get(8), departures.get("UA18").getFlightNumber() });
		bags.put("0005", new String[] { nodes.get(7), departures.get("ARRIVAL").getFlightNumber() });

		for (Map.Entry<String, String[]> bag : bags.entrySet()) {
			getPathDistance(bag);
		}

	}

	private void getPathDistance(Map.Entry<String, String[]> bag) {
		String bagName = bag.getKey();
		String[] strings = bag.getValue();
		shortestPathAlgo.execute(strings[0]);
		Map<Integer, LinkedList<String>> path = shortestPathAlgo.getPath(strings[1]);

		assertNotNull(path);
		assertTrue(path.size() > 0);
		
		for (Map.Entry<Integer,LinkedList<String>> pathDistance : path.entrySet()) {
			System.out.print(bagName+"\t");
			for(String string : pathDistance.getValue() ) {
				System.out.print( string + " ");
			}
			System.out.print(  ": " + pathDistance.getKey() );
			System.out.println();
		}
	}

	private void addLane(String laneId, int sourceLocNo, int destLocNo, int duration) {

		// Bidirectional Edges
		Edge lane = new Edge(nodes.get(sourceLocNo), nodes.get(destLocNo), laneId, duration);
		edges.add(lane);

		lane = new Edge( nodes.get(destLocNo), nodes.get(sourceLocNo), laneId, duration);
		edges.add(lane);
	}

}

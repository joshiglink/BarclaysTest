package com.barclays.airport.dto;

public class FlightInfo {
	
	private String flightNumber;
	private String gate;
	private String destination;
	private String timeOfDeparture;
	
	public FlightInfo(String flightNumber, String destination, String timeOfDeparture) {
		super();
		this.flightNumber = flightNumber;
		this.destination = destination;
		this.timeOfDeparture = timeOfDeparture;
	}
	
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getGate() {
		return gate;
	}
	public void setGate(String gate) {
		this.gate = gate;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getTimeOfDeparture() {
		return timeOfDeparture;
	}
	public void setTimeOfDeparture(String timeOfDeparture) {
		this.timeOfDeparture = timeOfDeparture;
	}

}

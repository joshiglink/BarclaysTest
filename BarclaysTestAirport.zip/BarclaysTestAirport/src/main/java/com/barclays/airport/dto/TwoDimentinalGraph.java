package com.barclays.airport.dto;

import java.util.List;

public class TwoDimentinalGraph {
	

	private final List<String> vertexes;
	private final List<Edge> edges;

	public TwoDimentinalGraph(List<String> vertexes, List<Edge> edges) {
		this.vertexes = vertexes;
		this.edges = edges;
	}

	public List<String> getVertexes() {
		return vertexes;
	}

	public List<Edge> getEdges() {
		return edges;
	}



}

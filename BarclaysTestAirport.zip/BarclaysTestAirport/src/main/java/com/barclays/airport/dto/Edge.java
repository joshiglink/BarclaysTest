package com.barclays.airport.dto;

public class Edge {
	
	private String name;
	private String previous;
	private String next;
	private int value;
	
	public Edge( String previous, String next, String name, int value) {
		this.previous = previous;
		this.next = next;
		this.name = name;
		this.value = value;
	}

	public String getNext() {
		return next;
	}

	public int getValue() {
		return value;
	}

	public String getPrevious() {
		return previous;
	}
	
	public String getName() {
		return name;
	}

}
